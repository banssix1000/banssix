from flask import Flask, request
from defs import db, js, dr
import datetime

app = Flask(__name__)

@app.route("/webhook", methods=["POST"])
def webhook_pushinpay():
    try:
        data = request.json

        if data.get("status") != "paid":
            return "ignored", 200

        custom_id = data.get("custom_id")
        if not custom_id:
            return "missing custom_id", 400

        # custom_id vem no formato: user_id|plano_id
        user_id, plano_id = custom_id.split("|")

        user_id = int(user_id)
        plano = db.getPlan(plano_id)

        if not plano:
            return "invalid plan", 400

        nome = plano[1]
        dias = plano[2]
        price = plano[3]
        valor = float(price)

        # Liberar acesso ao grupo VIP
        link = db.gerarLink(user_id)
        db.setPlano(user_id, plano_id)
        db.setColumnUsuario('link', link, user_id)

        if dias.lower() != "v":
            dias_int = int(dias)
            validade = datetime.datetime.now() + datetime.timedelta(days=dias_int)
            validade_str = validade.strftime("%d/%m/%Y")
            db.setColumnUsuario("plano_until", validade_str, user_id)
        else:
            db.setColumnUsuario("plano_until", "v", user_id)

        # Calcular comissão para o dono do sistema
        taxa_fixa = 1.50
        taxa_percentual = 5
        comissao = (valor * taxa_percentual / 100) + taxa_fixa
        db.addSaldo(comissao)

        return "ok", 200

    except Exception as e:
        print(f"Erro no webhook: {e}")
        return "error", 500

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=80)
