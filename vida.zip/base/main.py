#========================#

from defs import db, pg, js, dr
import telebot
from telebot.types import InlineKeyboardButton, InlineKeyboardMarkup, BotCommand
import time
from pushinpay import Pushinpay
import threading
import base64
from pushinpay import Pushinpay

#========================#

bot = telebot.TeleBot(js.getDict(dr.config, "bot_token"))

bot_commands = [
    BotCommand('start', 'Inicia o bot.'),
    BotCommand('status', 'Veja o status da sua assinatura.'),
    BotCommand('admin', 'Painel Administrativo.'),
    BotCommand('sobre', 'Sobre o bot.')
]

bot.set_my_commands(bot_commands)

gerando_pix = []
enviando_msg = []
sacando = []

#========================#

def getButtonsAdmin():
    try:
        mkp = InlineKeyboardMarkup(row_width=1)
        btn1 = InlineKeyboardButton('💬 Mensagem Inicial', callback_data="msg_inicial_config")
        btn2 = InlineKeyboardButton('🛒 Planos e Preços', callback_data="planos_config")
        btn3 = InlineKeyboardButton('💎 Grupo/Canal VIP', callback_data="grupo_config")
        btn4 = InlineKeyboardButton('👨‍💻 Suporte e Atendimento', callback_data="suporte_config")
        btn5 = InlineKeyboardButton('💬 Mensagens em Massa', callback_data="mensagem_config")
        btn6 = InlineKeyboardButton('👤 Saldo e Informações', callback_data="perfil_info")
        btn7 = InlineKeyboardButton("📊 Estatísticas", callback_data="estatisticas_config")
        btn8 = InlineKeyboardButton("Preciso de Ajuda", url="t.me/iderDetryu")
        mkp.add(btn1, btn2, btn3, btn4, btn5, btn6, btn7, btn8)
        return mkp
    except Exception as e:
        print(f"Erro ao formaar botoes admin: {e}")
        return None

def convertPrice(valor):
    try:
        if ',' in valor:
            valor = valor.replace(',', '.')
        return float(valor)
    except:
        return False

def getPlansButton():
    try:
        mkp = InlineKeyboardMarkup(row_width=1)
        planos = db.getAllPlans()
        for plano in planos:
            id = plano[0]
            nome = plano[1]
            dias = plano[2]
            price = plano[3]
            valor = convertPrice(price)
            if nome and dias and price:
                btn = InlineKeyboardButton(f'{nome} (R${valor:.2f})', callback_data=f"plano_mostrar**{id}")
                mkp.add(btn)
        return mkp
    except Exception as e:
        print(f"Erro ao formatar botões do plano: {e}")
        return None

def sendFaltandoItemPlano(plano_id, userid):
    try:
        plano = db.getPlan(plano_id)
        nome = plano[1]
        dias = plano[2]
        price = plano[3]

        if not nome:
            bot.send_message(userid, "Defina o nome do seu plano usando o comando abaixo:\n\n/nameplan <plano_id> <nome>")
        elif not dias:
            bot.send_message(userid, "Defina a válidade do seu plano usando o comando abaixo:\n\n/plandays <plano_id> <dias>\n\nObs: Utilize 'V' para definir o plano como vitalício ou insira um número que represente a duração do seu plano em dias. O bot removerá automaticamente o usuário do grupo quando o plano expirar.")
        elif not price:
            bot.send_message(userid, "Defina o preço do seu plano usando o comando abaixo:\n\n/planprice <plan_id> <price>")
    except:
        pass

def getChatName(chat_id):
    try:
        return bot.get_chat(chat_id).title
    except:
        return None

def getMenuMessage():
    try:
        with open('storage/menu.txt', "r", encoding="utf-8") as f:
            return f.read()
    except Exception as e:
        return f"Internal Error: {e}"

def setTextMessage(text):
    try:
        with open('storage/menu.txt', "w", encoding="utf-8") as f:
            f.write(text)
            return True
    except:
        return False

def setAction(new_action):
    try:
        config = js.getDict(dr.config)
        config['action'] = new_action
        return js.saveDict(config, dr.config)
    except:
        return False

def delGroupVip():
    try:
        config = js.getDict(dr.config)
        config['chat'] = None
        return js.saveDict(config, dr.config)
    except:
        return False

def setUserCPF(cpf):
    try:
        config = js.getDict(dr.config)
        config['person']['cpf'] = cpf
        return js.saveDict(config, dr.config)
    except:
        return False
    
def setUserName(nome):
    try:
        config = js.getDict(dr.config)
        config['person']['nome'] = nome
        return js.saveDict(config, dr.config)
    except:
        return False

def setGroupVip(id):
    try:
        config = js.getDict(dr.config)
        config['chat'] = id
        return js.saveDict(config, dr.config)
    except:
        return False

def setSuporte(suporte):
    try:
        config = js.getDict(dr.config)
        config['suporte'] = suporte
        return js.saveDict(config, dr.config)
    except:
        return False

def sendCompleteMessage(userid, msg_id):
    try:
        msg = "Mensagem configurada com sucesso!\nClique no botão abaixo para visualizar a prévia da mensagem. Quando estiver pronto, clique em 'Enviar' para iniciar o envio. Lembre-se: após o envio, não será possível desfazer."
        mkp = InlineKeyboardMarkup(row_width=2)
        btn = InlineKeyboardButton('👁 Ver Mensagem', callback_data=f"ver_msg**{msg_id}")
        btn1 = InlineKeyboardButton('✅ Enviar Mensagem', callback_data=f"enviar_msg**{msg_id}")
        btn2 = InlineKeyboardButton('❌ Cancelar', callback_data=f"deletar_mesagem**{msg_id}")
        mkp.add(btn, btn1, btn2)
        bot.send_message(userid, msg, reply_markup=mkp)
    except:
        pass

def enviarMensagemPersonalizada(msg_id, userid):
    try:
        mensagem = db.selectMessage(msg_id)

        media = mensagem[2]
        media_type = mensagem[3]
        message_text = mensagem[4]

        enviado = False

        if media_type and media:
            media = base64.b64decode(media)
            if media_type == 'photo':
                bot.send_photo(userid, media, message_text)
                enviado = True
            else:
                bot.send_video(userid, media, caption=message_text)
                enviado = True
        else:
            bot.send_message(userid, message_text)
            enviado = True

        return enviado
    
    except Exception as e:
        print(e)

#========================#

@bot.message_handler(commands=['start'], chat_types=['private'])
def startMessage(message):
    try:
        userid = message.from_user.id
        db.insertUser(userid)

        msg_txt = getMenuMessage()
        media, media_type = db.getMedia()
        mkp = getPlansButton()
        suporte = js.getDict(dr.config, "suporte")

        if suporte:
            admin_id = js.getDict(dr.config, "admin")
            btn = InlineKeyboardButton(' SUPPRTE 👨‍💻 ', url=f"tg://user?id={admin_id}")
            mkp.add(btn)

        if media and media_type:
            if media_type == "photo":
                #envia_foto
                bot.send_photo(userid, media, msg_txt, parse_mode="HTML", reply_markup=mkp)

            elif media_type == "video":
                #envia_video
                bot.send_video(userid, media, caption=msg_txt, parse_mode="HTML", reply_markup=mkp)
        else:
            bot.send_message(userid, msg_txt, parse_mode="HTML", reply_markup=mkp)
    except Exception as e:
        print(f"Erro ao enviar mensagem start: {e}")

#========================#

@bot.message_handler(commands=['texto'], chat_types=['private'])
def mudarTexto(message):
    try:
        userid = message.from_user.id
        db.insertUser(userid)
        admin = js.getDict(dr.config, "admin")

        if str(userid) != str(admin):
            return
        
        msg_text = message.text.split(' ', 1)[1] if len(message.text.split(' ', 1)) == 2 else None
        if not msg_text:
            bot.reply_to(message, "Use o comando neste formato:\n\n/texto texto_aqui")
        else:
            enviado = False

            try:
                bot.send_message(userid, msg_text, parse_mode="HTML")
                enviado = True
            except:
                pass

            if not enviado:
                bot.send_message(userid, "Formato de mensagem inválido.")
            else:
                if setTextMessage(msg_text):
                    bot.send_message(userid, "✅ Mensagem inicial salva!")
                else:
                    bot.send_message(userid, "❌ Erro ao salvar mensagem.")
    except Exception as e:
        print(f"Erro no text config: {e}")

@bot.message_handler(commands=['admin'], chat_types=['private'])
def comandosAdmin(message):
    try:
        userid = message.from_user.id
        db.insertUser(userid)
        admin = js.getDict(dr.config, "admin")
        if str(userid) != str(admin):
            bot.send_message(userid, "🛡 Você não tem autorização para acessar esta área.")
            return
        
        msg_txt = "💡 Aqui estão todas as funcionalidades administrativas:"
        mkp = getButtonsAdmin()
        bot.send_message(userid, msg_txt, reply_markup=mkp)
    except Exception as e:
        print(f"Erro ao enviar mensagem admin: {e}")

@bot.message_handler(commands=['midia'], chat_types=['private'])
def alterarMidia(message):
    try:
        userid = message.from_user.id
        db.insertUser(userid)
        admin = js.getDict(dr.config, "admin")
        if str(userid) != str(admin):
            return
        
        if setAction('midia_inicial'):
            bot.send_message(userid, '👇 Envie um vídeo ou imagem para adicionar à mensagem de boas-vindas, ou digite /cancelar para desistir.')
        else:
            bot.send_message(userid, "Ocorreu um erro. Por favor, tente novamente.")
    except Exception as e:
        print(f"Erro ao enviar mensagem de enviar midia: {e}")

@bot.message_handler(commands=['delmidia'], chat_types=['private'])
def deletarMidiaInicial(message):
    try:
        userid = message.from_user.id
        db.insertUser(userid)
        admin = js.getDict(dr.config, "admin")
        if str(userid) != str(admin):
            return
        if db.deleteMidia():
            bot.send_message(userid, '✅ Mídia deletada com sucesso!')
        else:
            bot.send_message(userid, '❌ Erro ao deletar mídia.')
    except Exception as e:
        print(f"Erro no deletar mídia msg: {e}")

@bot.message_handler(commands=['newplan'], chat_types=['private'])
def newPlanMessage(message):
    try:
        userid = message.from_user.id
        db.insertUser(userid)
        admin = js.getDict(dr.config, "admin")
        if str(userid) != str(admin):
            return
        
        plan_id = db.criarPlan()

        if plan_id:
            msg = f"✅ Plano criado com sucesso!\n\nID do plano: <code>{plan_id}</code>"
            mensagem = f"Aqui estão os comandos disponíveis para gerenciamento de planos:\n\n- /nameplan &lt;plan_id&gt; &lt;nome_plano&gt;\nDefine o nome do plano.\n\nExemplo: <code>/nameplan {plan_id} Plano Premium</code>\n\n- /plandays &lt;plan_id&gt; &lt;dias|V&gt;\nDefine a duração do plano em dias ou &quot;V&quot; para vitalício.\n\nExemplo: <code>/plandays {plan_id} 30</code> (para 30 dias)\nou\n<code>/plandays {plan_id} V</code> (para plano vitalício)\n\n- /planprice &lt;plan_id&gt; &lt;preço&gt;\nDefine o preço do plano.\n\nExemplo: <code>/planprice {plan_id} 49.90</code>\n\n- <code>/vplans</code>: Exibe a lista de planos criados.\n\n- /delplan &lt;plan_id&gt;\nExclui um plano existente.\n\nExemplo: <code>/delplan {plan_id}</code>"
            bot.send_message(userid, msg, parse_mode="HTML")
            bot.send_message(userid, mensagem, parse_mode="HTML")
        else:
            bot.send_message(userid, "Não foi possivel criar o plano.")
    except Exception as e:
        print(f"Erro ao criar plano msg: {e}")

@bot.message_handler(commands=['nameplan'], chat_types=['private'])
def namePlan(message):
    try:
        userid = message.from_user.id
        db.insertUser(userid)
        admin = js.getDict(dr.config, "admin")
        if str(userid) != str(admin):
            return
        
        resultados = message.text.split(' ', 2)
        if len(resultados) == 3:
            plan_id = resultados[1]
            nome_plano = resultados[2]

            if not db.getPlan(plan_id):
                bot.send_message(userid, 'Plano não encontrado. Use /vplans para ver os planos criados.')
                return
            if len(nome_plano) < 5 or len(nome_plano) > 30:
                bot.send_message(userid, "O nome do plano tem que estar entre 5 e 30 caracteres.")
                return
            if db.editarColunaPlan(plan_id, 'name', nome_plano):
                bot.send_message(userid, '✅ Configuração salva!')
                sendFaltandoItemPlano(plan_id, userid)
            else:
                bot.send_message(userid, "❌ Não foi possível salvar as configurações.")
        else:
            bot.send_message(userid, "Use nesse formato:\n\n/nameplan <plan_id> <name_plan>")
    
    except Exception as e:
        print(f"Erro ao definir nome plan message: {e}")

@bot.message_handler(commands=['plandays'], chat_types=['private'])
def daysPlan(message):
    try:
        userid = message.from_user.id
        db.insertUser(userid)
        admin = js.getDict(dr.config, "admin")
        if str(userid) != str(admin):
            return
        
        resultados = message.text.split(' ', 2)
        if len(resultados) == 3:
            plan_id = resultados[1]
            plan_days = resultados[2]

            if not db.getPlan(plan_id):
                bot.send_message(userid, 'Plano não encontrado. Use /vplans para ver os planos criados.')
                return
            if plan_days.isdigit() or plan_days.lower() == "v":
                if db.editarColunaPlan(plan_id, 'days', plan_days):
                    bot.send_message(userid, '✅ Configuração salva!')
                    sendFaltandoItemPlano(plan_id, userid)
                else:
                    bot.send_message(userid, "❌ Não foi possível salvar as configurações.")
            else:
                bot.send_message(userid, 'Valor inválido. Use números ou V para definir a validade do plano.')
        else:
            bot.send_message(userid, "Use nesse formato:\n\n/plandays <plan_id> <dias/V>")
    
    except Exception as e:
        print(f"Erro ao definir nome plan message: {e}")

@bot.message_handler(commands=['planprice'], chat_types=['private'])
def pricePlan(message):
    try:
        userid = message.from_user.id
        db.insertUser(userid)
        admin = js.getDict(dr.config, "admin")
        if str(userid) != str(admin):
            return
        
        resultados = message.text.split(' ', 2)
        if len(resultados) == 3:
            plan_id = resultados[1]
            plan_price = resultados[2]

            if not db.getPlan(plan_id):
                bot.send_message(userid, 'Plano não encontrado. Use /vplans para ver os planos criados.')
                return
            
            valor = convertPrice(plan_price)

            if not valor:
                bot.send_message(userid, 'Preço inválido! Use valores nesse formato: 10, 12.50 ou 13,40.')
                return
            if valor < 1 or valor > 300:
                bot.send_message(userid, 'O preço do plano tem que estar entre R$1.00 e R$300.00.')
                return
            
            if db.editarColunaPlan(plan_id, 'price', valor):
                bot.send_message(userid, '✅ Configuração salva!')
                sendFaltandoItemPlano(plan_id, userid)
            else:
                bot.send_message(userid, '❌ Erro ao salvar configurações.')
        else:
            bot.send_message(userid, "Use nesse formato:\n\n/planprice <plan_id> <valor>")
    except Exception as e:
        print(f"Erro ao definir nome plan message: {e}")

@bot.message_handler(commands=['vplans'], chat_types=['private'])
def verPlanos(message):
    try:
        userid = message.from_user.id
        db.insertUser(userid)
        admin = js.getDict(dr.config, "admin")
        if str(userid) != str(admin):
            return
        planos = db.getAllPlans()
        if not planos:
            bot.send_message(userid, "Você ainda não criou nenhum plano. Crie um novo plano usando o comando /newplan.")
        else:
            msg_txt = "Aqui estão todos os planos criados:"
            for plano in planos:
                id = plano[0]
                nome = plano[1]
                dias = plano[2]
                price = plano[3] 

                valor = convertPrice(price)

                if nome and dias and price:
                    status = "✅ Configurado"
                else:
                    status = "🛠 Configuração Pendente"
                
                nome = nome or "N/A"
                dias = dias or "N/A"

                if valor:
                    valor = f"R${valor:.2f}"
                else:
                    valor = price or "N/A"
            
                msg_txt += f"\n\n#========#\n\nID: <code>{id}</code>\nNome: {nome}\nDias: {'Vitalício' if dias.lower() == 'v' else dias}\nPreço: {valor}\nStatus: {status}"
            msg_txt += "\n\n#========#\n\nObs: Clique no ID de algum plano para copiar."
            bot.send_message(userid, msg_txt, parse_mode="HTML")
    except Exception as e:
        print(f"Erro ao listar planos: {e}")

@bot.message_handler(commands=['delplan'], chat_types=['private'])
def deletarPlano(message):
    try:
        userid = message.from_user.id
        db.insertUser(userid)
        admin = js.getDict(dr.config, "admin")
        if str(userid) != str(admin):
            return
        plan_id = message.text.split(' ', 1)[1] if len(message.text.split(' ', 1)) == 2 else None
        if not plan_id:
            bot.send_message(userid, 'Use nesse formato:\n\n/delplan <plan_id>')
            return
        if not db.getPlan(plan_id):
            bot.send_message(userid, 'Plano não encontrado. Use /vplans para ver os planos criados.')
            return
        if db.deletePlan(plan_id):
            bot.send_message(userid, '✅ Plano deletado com sucesso!')
        else:
            bot.send_message(userid, '❌ Não foi possível deletar o plano.')
        
    except Exception as e:
        print(f"Erro ao deletar plano message: {e}")

@bot.message_handler(commands=['setvip'], chat_types=['private'])
def setVip(message):
    try:
        userid = message.from_user.id
        db.insertUser(userid)
        admin = js.getDict(dr.config, "admin")
        if str(userid) != str(admin):
            return
        
        chat_id = message.text.split(' ', 1)[1] if len(message.text.split(' ', 1)) == 2 else None

        if not chat_id:
            bot.send_message(userid, "Use neste formato:\n\n/setvip <grupo_id>")
            return
        
        chat_title = getChatName(chat_id)

        if not chat_title:
            bot.send_message(userid, 'Não foi possível pegar informações do grupo. Verifique se o ID está correto e se o bot é administrador do grupo.')
            return
        
        if setGroupVip(chat_id):
            bot.send_message(userid, f'✅ O grupo VIP foi definido: {chat_title}')
        else:
            bot.send_message(userid, '❌ Erro ao definir grupo VIP.')
    except Exception as e:
        print(f"Erro ao definir grupo vip: {e}")

@bot.message_handler(commands=['delvip'], chat_types=['private'])
def delVip(message):
    try:
        userid = message.from_user.id
        db.insertUser(userid)
        admin = js.getDict(dr.config, "admin")
        if str(userid) != str(admin):
            return
        
        if delGroupVip():
            bot.send_message(userid, f'✅ Grupo VIP removido!')
        else:
            bot.send_message(userid, '❌ Erro ao remover grupo VIP.')
    except Exception as e:
        print(f"Erro ao definir grupo vip: {e}")

@bot.message_handler(commands=['setcpf'], chat_types=['private'])
def setCPF(message):
    try:
        userid = message.from_user.id
        db.insertUser(userid)
        admin = js.getDict(dr.config, "admin")
        if str(userid) != str(admin):
            return
        
        cpf = message.text.split(' ', 1)[1] if len(message.text.split(' ', 1)) == 2 else None

        if not cpf:
            bot.send_message(userid, "Use neste formato:\n\n/setcpf <cpf>")
            return
        
        if setUserCPF(cpf):
            bot.send_message(userid, f'✅ O CPF foi definido: {cpf}')
        else:
            bot.send_message(userid, '❌ Erro ao definir CPF.')
    except Exception as e:
        print(f"Erro ao definir cpf: {e}")

@bot.message_handler(commands=['setnome'], chat_types=['private'])
def setNome(message):
    try:
        userid = message.from_user.id
        db.insertUser(userid)
        admin = js.getDict(dr.config, "admin")
        if str(userid) != str(admin):
            return
        
        nome = message.text.split(' ', 1)[1] if len(message.text.split(' ', 1)) == 2 else None

        if not nome:
            bot.send_message(userid, "Use neste formato:\n\n/setnome <nome>")
            return
        
        if setUserName(nome):
            bot.send_message(userid, f'✅ O Nome foi definido: {nome}')
        else:
            bot.send_message(userid, '❌ Erro ao definir Nome.')
    except Exception as e:
        print(f"Erro ao definir nome: {e}")

@bot.message_handler(commands=['send_msg'], chat_types=['private'])
def sendMessages(message):
    try:
        userid = message.from_user.id
        db.insertUser(userid)
        admin = js.getDict(dr.config, "admin")
        if str(userid) != str(admin):
            return
        
        msg = f"💬 Para quem você deseja enviar uma mensagem?"
        mkp = InlineKeyboardMarkup()
        btno = InlineKeyboardButton('🔥 Todos os Usuários', callback_data=f"send_msg**todos")
        btn = InlineKeyboardButton('👑 Assinantes', callback_data=f"send_msg**assinantes")
        btn1 = InlineKeyboardButton('👥 Não Assinantes', callback_data="send_msg**n_assinantes")
        btn2 = InlineKeyboardButton('👤 Privado', callback_data="send_msg**privado")
        mkp.row(btno)
        mkp.row(btn, btn1)
        mkp.row(btn2)
        bot.send_message(userid, msg, reply_markup=mkp)
    except Exception as e:
        print(f"erro ao enviar mensagens de mensamg=: {e}")

@bot.message_handler(commands=['status'], chat_types=['private'])
def statusAssinatura(message):
    try:
        userid = message.from_user.id
        db.insertUser(userid)
        userdata = db.getUserById(userid)

        link = userdata[2]
        validade = userdata[3]

        if not link or not validade:
            bot.send_message(userid, "Você ainda não comprou nenhum acesso neste bot.")
            return
        
        msg = f"Seus dados de acesso:\n\nExpira Em: {'Vitalício' if validade.lower() == 'v' else validade}\nLink de acesso: {link}"

        bot.send_message(userid, msg, disable_web_page_preview=True)
    except:
        pass

@bot.message_handler(commands=['sobre'], chat_types=['private'])
def sobreBotMessage(message):
    try:
        userid = message.from_user.id
        db.insertUser(userid)
        dev = js.getDict(dr.config, "dev")
        msg = f"Este bot gerenciador foi desenvolvido utilizando o @VENIXGERENCIADORBOT. Gostaríamos de esclarecer que não somos proprietários de canais ou grupos. Nosso objetivo é proporcionar a todos a oportunidade de criar seu próprio bot administrador de forma totalmente gratuita.\n\nEmbora não tenhamos responsabilidade sobre o conteúdo gerado, estamos sempre prontos para cooperar e remover bots que compartilhem conteúdos impróprios. Oferecemos a liberdade para que cada um crie seu bot e utilize-o para vender e promover seus próprios conteúdos, sem qualquer envolvimento da nossa parte.\n\nReiteramos que não armazenamos, participamos ou cooperamos com essas transações. Apenas facilitamos a criação dos bots, e todos são livres para gerenciar suas atividades.\n\nSe você encontrar qualquer problema, não hesite em nos contatar.\n@{dev}"
        bot.send_message(userid, msg)
    except:
        pass

#========================#

@bot.message_handler(content_types=['photo', 'video'], chat_types=['private'])
def handle_media(message):
    try:
        userid = message.from_user.id
        db.insertUser(userid)
        admin = js.getDict(dr.config, "admin")
        action = js.getDict(dr.config, "action")

        if str(userid) != str(admin):
            return
        
        if action == "midia_inicial":

            if message.content_type == 'photo':
                file_info = bot.get_file(message.photo[-1].file_id)
            elif message.content_type == 'video':
                file_info = bot.get_file(message.video.file_id)

            media_bytes = bot.download_file(file_info.file_path)

            if setAction('nenhum') and db.gravarMidia(media_bytes, message.content_type):
                bot.send_message(userid, '✅ Mídia salva!')
            else:
                bot.send_message(userid, '❌ Não foi possível salvar mídia.')
        elif 'send_message' in action:

            msg_id = action.split('**', 2)[1]
            elemento = action.split('**', 2)[2]

            if elemento == "media":

                if message.content_type == 'photo':
                    file_info = bot.get_file(message.photo[-1].file_id)
                elif message.content_type == 'video':
                    file_info = bot.get_file(message.video.file_id)

                media_bytes = bot.download_file(file_info.file_path)
                bytes_string = base64.b64encode(media_bytes).decode('utf-8')
                if db.setColumnMessage(msg_id, 'media', bytes_string) and db.setColumnMessage(msg_id, 'media_type', message.content_type) and setAction('nenhum'):
                    sendCompleteMessage(userid, msg_id)

    except Exception as e:
        print(f"Erro ao inserir midia: {e}")

@bot.message_handler(content_types=['text'], chat_types=['private'])
def handle_message(message):
    try:
        userid = message.from_user.id
        db.insertUser(userid)
        admin = js.getDict(dr.config, "admin")
        action = js.getDict(dr.config, "action")

        if str(userid) != str(admin):
            return
        
        if "send_message" in action:
            msg_id = action.split('**', 2)[1]
            elemento = action.split('**', 2)[2]
            
            if elemento == "user_id":

                user = message.text
                if user == "nao configurado":
                    bot.send_message(userid, 'Envie um id válido.')
                    return
                if db.setColumnMessage(msg_id, 'to', user) and setAction(f'send_message**{msg_id}**msg_txt'):
                    bot.send_message(userid, '✅ Salvo! Me envie o texto da mensagem:')

            if elemento == "msg_txt":
                msg_txt = message.text
                if msg_txt == "nao configurado":
                    bot.send_message(userid, 'Envie uma mensagem válida.')
                    return
                if db.setColumnMessage(msg_id, 'message_text', msg_txt) and setAction(f"nenhum"):
                    mkp = InlineKeyboardMarkup(row_width=2)
                    btn = InlineKeyboardButton('❌ Não', callback_data=f'set_midia**{msg_id}**no')
                    btn1 = InlineKeyboardButton('✅ Sim', callback_data=f'set_midia**{msg_id}**sim')
                    mkp.add(btn, btn1)
                    bot.send_message(userid, '✅ Salvo! Deseja adicionar uma imagem/vídeo à mensagem?', reply_markup=mkp)
        
    except:
        pass

#========================#

@bot.callback_query_handler(func=lambda call: call.data == "msg_inicial_config")
def enviarComandosMsgInicial(call):
    try:
        userid = call.from_user.id
        msg = "Utilize os comandos abaixo para personalizar a mensagem de boas-vindas do bot:\n\n- /texto: Altera o texto da mensagem de boas-vindas.\n- /midia: Adiciona uma imagem ou vídeo à mensagem de boas-vindas.\n- /delmidia: Remove a imagem ou vídeo da mensagem de boas-vindas."
        mkp = InlineKeyboardMarkup(row_width=1)
        btn = InlineKeyboardButton('<< Voltar', callback_data="menu_adm")
        mkp.add(btn)
        bot.edit_message_text(msg, userid, call.message.message_id, parse_mode="HTML", reply_markup=mkp)
    except Exception as e:
        print(f"Erro ao enviar mensagem de comandos iniciais: {e}")

@bot.callback_query_handler(func=lambda call: call.data == "planos_config")
def msgPlanosConfig(call):
    try:
        userid = call.from_user.id
        plan_id = "abc123"
        msg = f"Gerencie os planos utilizando os comandos abaixo:\n\n- /newplan: Cria um novo plano.\n\n- /nameplan &lt;plan_id&gt; &lt;nome_plano&gt;\nDefine o nome do plano.\n\nExemplo: <code>/nameplan {plan_id} Plano Premium</code>\n\n- /plandays &lt;plan_id&gt; &lt;dias|V&gt;\nDefine a duração do plano em dias ou &quot;V&quot; para vitalício.\n\nExemplo: <code>/plandays {plan_id} 30</code> (para 30 dias)\nou\n<code>/plandays {plan_id} V</code> (para plano vitalício)\n\n- /planprice &lt;plan_id&gt; &lt;preço&gt;\nDefine o preço do plano.\n\nExemplo: <code>/planprice {plan_id} 49.90</code>\n\n- <code>/vplans</code>: Exibe a lista de planos criados.\n\n- /delplan &lt;plan_id&gt;\nExclui um plano existente.\n\nExemplo: <code>/delplan {plan_id}</code>"
        mkp = InlineKeyboardMarkup(row_width=1)
        btn = InlineKeyboardButton('<< Voltar', callback_data="menu_adm")
        mkp.add(btn)
        bot.edit_message_text(msg, userid, call.message.message_id, parse_mode="HTML", reply_markup=mkp)
    except Exception as e:
        print(f"Erro no planos msg: {e}")

@bot.callback_query_handler(func=lambda call: call.data == "menu_adm")
def menuAdm(call):
    try:
        userid = call.from_user.id
        admin = js.getDict(dr.config, "admin")
        if str(userid) != str(admin):
            return
        
        msg_txt = "💡 Aqui estão todas as funcionalidades administrativas:"
        mkp = getButtonsAdmin()
        bot.edit_message_text(msg_txt, userid, call.message.message_id, reply_markup=mkp)
    except Exception as e:
        print(f"Erro ao enviar mensagem admin: {e}")

@bot.callback_query_handler(func=lambda call: call.data == "grupo_config")
def configGrupoCall(call):
    try:
        userid = call.from_user.id
        msg = "Para adicionar um canal ou grupo para que o bot gerencie, siga estes passos:\n\n1. Adicione este bot ao grupo ou canal, garantindo que ele tenha permissão de administrador, incluindo a de remover membros.\n2. Obtenha o ID do grupo ou canal.\n3. Utilize os comandos abaixo:\n\n- /setvip <id_grupo>: Define o grupo ou canal VIP.\n- /delvip: Remove o grupo ou canal VIP.\n\nSe tiver dúvidas sobre como obter o ID do canal ou grupo, entre em contato com o suporte."
        mkp = InlineKeyboardMarkup(row_width=1)
        btn = InlineKeyboardButton('<< Voltar', callback_data="menu_adm")
        mkp.add(btn)
        bot.edit_message_text(msg, userid, call.message.message_id, reply_markup=mkp)
    except:
        pass

@bot.callback_query_handler(func=lambda call: call.data == "suporte_config")
def suporte_config(call):
    try:
        userid = call.from_user.id
        suporte = js.getDict(dr.config, "suporte")
        status_suporte = "✅ Ativo" if suporte else "❌ Desativo"
        msg = f"👨‍💻 Ative a opção de suporte e atraia mais clientes!\n\nObs: Eles serão redirecionados para seu perfil do Telegram.\n\nSuporte: {status_suporte}"
        
        mkp = InlineKeyboardMarkup(row_width=1)
        btn = InlineKeyboardButton('Ativar Suporte' if not suporte else 'Desativar Suporte', callback_data="suporte_on_off")
        voltar = InlineKeyboardButton('<< Voltar', callback_data="menu_adm")
        mkp.add(btn, voltar)
        bot.edit_message_text(msg, userid, call.message.message_id, reply_markup=mkp)
    except:
        pass

@bot.callback_query_handler(func=lambda call: call.data == "suporte_on_off")
def suporteOnOff(call):
    try:
        suporte = js.getDict(dr.config, "suporte")
        if not suporte:
            setSuporte(True)
        else:
            setSuporte(False)
        suporte_config(call)
    except:
        pass

@bot.callback_query_handler(func=lambda call: "plano_mostrar" in call.data)
def mostrar_plano(call):
    try:
        userid = call.from_user.id
        plano_id = call.data.split('**', 1)[1]
        plano_data = db.getPlan(plano_id)

        id = plano_data[0]
        nome = plano_data[1]
        dias = plano_data[2]
        price = plano_data[3]

        price = convertPrice(price)

        msg = f"🛒 Detalhes do Plano:\n\n🏷 Nome: {nome}\n🗓 Validade: {'Vitalício' if dias.lower() == 'v' else f'{dias} dias'}\n💳 Custo: R${price:.2f}\n\n🔹 Escolha a forma de pagamento:"
        mkp = InlineKeyboardMarkup(row_width=1)
        btn = InlineKeyboardButton("💠 Pix 💠", callback_data=f"gerar_pix**{id}")
        voltar = InlineKeyboardButton('<< Voltar', callback_data="menu_principal")
        mkp.add(btn, voltar)
        try:
            bot.delete_message(userid, call.message.message_id)
        except:
            pass
        bot.send_message(userid, msg, reply_markup=mkp)
    except Exception as e:
        print(f"Erro ao enviar mostrar plano: {e}")

@bot.callback_query_handler(func=lambda call: "menu_principal" in call.data)
def menuPrincipal(call):
    try:
        try:
            bot.delete_message(call.from_user.id, call.message.message_id)
        except:
            pass
        userid = call.from_user.id
        msg_txt = getMenuMessage()
        media, media_type = db.getMedia()
        mkp = getPlansButton()
        suporte = js.getDict(dr.config, "suporte")

        if suporte:
            admin_id = js.getDict(dr.config, "admin")
            btn = InlineKeyboardButton(' SUPORTE 👨‍💻 ', url=f"tg://user?id={admin_id}")
            mkp.add(btn)

        if media and media_type:
            if media_type == "photo":
                #envia_foto
                bot.send_photo(userid, media, msg_txt, parse_mode="HTML", reply_markup=mkp)

            elif media_type == "video":
                #envia_video
                bot.send_video(userid, media, caption=msg_txt, parse_mode="HTML", reply_markup=mkp)
        else:
            bot.send_message(userid, msg_txt, parse_mode="HTML", reply_markup=mkp)
    except:
        pass

@bot.callback_query_handler(func=lambda call: "gerar_pix**" in call.data)
def gerarPixCall(call):
    try:

        userid = call.from_user.id

        if userid in gerando_pix:
            return
        gerando_pix.append(userid)

        try:
            msg_carregando = bot.send_message(userid, "⏳").message_id
        except:
            pass

        canal_id = js.getDict(dr.config, "chat")
        admin = js.getDict(dr.config, "admin")
        plano_id = call.data.split("**", 1)[1]
        if not canal_id:
            try:
                bot.delete_message(userid, msg_carregando)
            except:
                pass
            try:
                bot.send_message(userid, "Ocorreu um erro ao gerar seu pagamento.")
            except:
                pass
            bot.send_message(admin, "⚠ ATENÇÃO! ⚠\n\nUm usuário tentou adquirir um plano, mas seu canal ou grupo VIP ainda não está configurado. Para evitar problemas futuros, use o comando /admin e adicione o canal ou grupo VIP o quanto antes.")
        else:
                            plano = db.getPlan(plano_id)
        id = plano[0]
        nome = plano[1]
        dias = plano[2]
        price = plano[3]
        price = convertPrice(price)


        pushinpay_token = js.getDict(dr.config, "pushinpay_token")
        webhook_url = "https://SEU_DOMINIO_AQUI/webhook"
        ppay = Pushinpay(pushinpay_token)
        pixCopiaECola, qrcode_bytes = ppay.criar_pagamento(userid, plano_id, nome, price, webhook_url)
    
            try:
                bot.delete_message(userid, msg_carregando)
            except:
                pass
            if pixCopiaECola:

                plano = db.getPlan(plano_id)
                id = plano[0]
                nome = plano[1]
                dias = plano[2]
                price = plano[3]
                price = convertPrice(price)
                
                msg = f"✅ Pagamento gerado com sucesso!\n\n📌 Para concluir, clique no código abaixo para copiá-lo e cole na opção Pix - Copia e Cola do seu banco. Realize o pagamento seguindo as instruções do seu app bancário.\n\n💵 Valor: R$ {price:.2f}\n📅 Validade do Plano: {'Vitalício' if dias.lower() == 'v' else f'{dias} dias'}\n\n🔗 Código Copia e Cola:\n\n<code>{pixCopiaECola}</code>\n\n⏳ Assim que o pagamento for confirmado, você receberá automaticamente o link de acesso."

                bot.send_message(userid, msg, parse_mode="HTML")
            else:
                try:
                    bot.send_message(userid, "Ocorreu um erro ao gerar seu pagamento.")
                except:
                    pass
                try:
                    bot.send_message(userid, "Ocorreu um erro ao gerar o pagamento. Por favor, entre em contato com o administrador do bot para que o problema seja resolvido o mais rápido possível.")
                except:
                    pass
        gerando_pix.remove(userid)
    except:
        try:
            gerando_pix.remove(userid)
        except:
            pass

@bot.callback_query_handler(func=lambda call: "perfil_info" in call.data)
def perfilAdmin(call):
    try:

        config = js.getDict(dr.config)

        admin = config['admin']
        taxa_saque = config['taxa_saque']
        taxa_venda = config['taxa_venda']
        cpf = config['person']['cpf']
        nome = config['person']['nome']
        saldo = db.getSaldo()

        msg = f"👤 Perfil Administrativo\n\n🆔 ID Admin: {admin}\n📉 Taxa de Saque: {taxa_saque}%\n📈 Taxa de Venda: {taxa_venda}%\n💳 Seu CPF: {f'{cpf} [ /setcpf ]' or 'N/A'}\n📝 Nome: {f'{nome} [ /setnome ]' or 'N/A'}\n\n💸 Saldo Atual: R${saldo:.2f}"

        if not cpf or not nome:
            msg += "\n\n⚠ Avisos:"
            if not cpf:
                msg += "\n- Por favor, insira seu CPF utilizando o comando /setcpf. Isso é necessário para que possamos processar seus saques corretamente."
            if not nome:
                msg += "\n- Por favor, defina seu nome utilizando o comando /setnome. Isso é necessário para que possamos processar seus saques corretamente."
        
        mkp = InlineKeyboardMarkup(row_width=1)
        btn1 = InlineKeyboardButton('💸 Realizar um Saque', callback_data="sacar_fundos")
        btn = InlineKeyboardButton("<< Voltar", callback_data="menu_adm")
        mkp.add(btn1, btn)
        bot.edit_message_text(msg, admin, call.message.message_id, reply_markup=mkp)
    except Exception as e:
        print(e)

@bot.callback_query_handler(func=lambda call: call.data == "mensagem_config")
def mensagemCall(call):
    try:
        userid = call.from_user.id
        msg_id = call.message.message_id
        msg = "Use o comando abaixo para enviar mensagens para seus usuários:\n\n/send_msg - Abre o menu de envio de mensagens."
        mkp = InlineKeyboardMarkup(row_width=1)
        btn = InlineKeyboardButton("<< Voltar", callback_data="menu_adm")
        mkp.add(btn)
        bot.edit_message_text(msg, userid, msg_id, reply_markup=mkp)
    except:
        pass

@bot.callback_query_handler(func=lambda call: "send_msg**" in call.data)
def criarMensagem(call):
    try:
        userid = call.from_user.id
        to = call.data.split('**', 1)[1]
        msg_id = db.createMessage(to)
        if not msg_id:
            bot.send_message(userid, "Não foi possível dar início.")
        else:
            try:
                bot.delete_message(userid, call.message.message_id)
            except:
                pass
            if to == 'privado':
                setAction(f'send_message**{msg_id}**user_id')
                bot.send_message(userid, 'Me envie o id do usuário:')
            else:
                setAction(f'send_message**{msg_id}**msg_txt')
                bot.send_message(userid, 'Me envie o texto da mensagem:')
    except:
        pass

@bot.callback_query_handler(func=lambda call: "set_midia**" in call.data)
def setMidia(call):
    try:
        userid = call.from_user.id
        answer = call.data.split('**', 2)[2]
        msg_id = call.data.split('**', 2)[1]
        if answer == "no":
            try:
                bot.delete_message(userid, call.message.message_id)
            except:
                pass
            db.setColumnMessage(msg_id, 'media', None)
            db.setColumnMessage(msg_id, 'media_type', None)
            setAction('nenhum')
            sendCompleteMessage(userid, msg_id)
        else:
            try:
                bot.delete_message(userid, call.message.message_id)
            except:
                pass
            if setAction(f'send_message**{msg_id}**media'):
                bot.send_message(userid, 'Me envie um(a) imagem/vídeo que será adicionado(a) à mensagem: 👇')
    except:
        pass

@bot.callback_query_handler(func=lambda call: "ver_msg**" in call.data)
def verMsg(call):
    try:
        userid = call.from_user.id
        msg_id = call.data.split('**', 1)[1]
        if not enviarMensagemPersonalizada(msg_id, userid):
            bot.send_message(userid, "Não foi possível visualizar mensagem.")
    except:
        pass

@bot.callback_query_handler(func=lambda call: "enviar_msg**" in call.data)
def enviarMensagensMassa(call):
    try:
        userid = call.from_user.id
        msg_id = call.data.split('**', 1)[1]

        if userid in enviando_msg:
            try:
                bot.answer_callback_query(call.id, "⚠ Aguarde o bot concluir o envio das mensagens antes de tentar novamente.")
            except:
                pass
            return
        
        enviando_msg.append(userid)

        msg = db.selectMessage(msg_id)
        
        to = msg[1]

        envios = 0
        erros = 0

        try:
            bot.delete_message(userid, call.message.message_id)
        except:
            pass

        try:
            msg_to_delete = bot.send_message(userid, "⏳").message_id
        except:
            msg_to_delete = None

        if to == "assinantes":
            assinantes = db.getAssinantes()
            for assinante in assinantes:
                id_assinante = assinante[0]
                if enviarMensagemPersonalizada(msg_id, id_assinante):
                    envios += 1
                else:
                    erros += 1
        elif to == "n_assinantes":
            n_assinantes = db.getNotAssinantes()
            for assinante in n_assinantes:
                id_assinante = assinante[0]
                if enviarMensagemPersonalizada(msg_id, id_assinante):
                    envios += 1
                else:
                    erros += 1
        elif to == "todos":
            usuarios = db.getAllUsers()
            for usuario in usuarios:
                id_user = usuario[0]
                if enviarMensagemPersonalizada(msg_id, id_user):
                    envios += 1
                else:
                    erros += 1
        else:
            if enviarMensagemPersonalizada(msg_id, to):
                envios += 1
            else:
                erros += 1

        msg = f"Relatório de envios:\n\n✅ Envios bem-sucedidos: {envios}\n❌ Falhas: {erros}"
        if erros:
            msg += "\n\nObs: As falhas podem ocorrer quando o usuário bloqueou o bot ou ainda não iniciou o bot usando o comando /start."

        try:
            bot.delete_message(userid, msg_to_delete)
        except:
            pass

        bot.send_message(userid, msg)

        enviando_msg.remove(userid)
        db.deleteMessage(msg_id)
    except Exception as e:
        print(f"Erro ao enviar mensagens massa: {e}")
        try:
            enviando_msg.remove(userid)
        except:
            pass

@bot.callback_query_handler(func=lambda call: "deletar_mesagem" in call.data)
def deletarMessage(call):
    try:
        userid = call.from_user.id
        msg_id = call.data.split('**', 1)[1]
        try:
            bot.delete_message(userid, call.message.message_id)
        except:
            pass
        db.deleteMessage(msg_id)
        bot.send_message(userid, "✅ Ação cancelada!")
    except Exception as e:
        print(e)

@bot.callback_query_handler(func=lambda call: call.data == "sacar_fundos")
def sacarFundosCall(call):
    try:
        config = js.getDict(dr.config)
        userid = call.from_user.id

        admin = config['admin']
        taxa_saque = config['taxa_saque']
        taxa_venda = config['taxa_venda']
        cpf = config['person']['cpf']
        nome = config['person']['nome']
        saldo = db.getSaldo()

        if not cpf:
            bot.send_message(userid, "Seu CPF ainda não está configurado. Para configurá-lo, use o comando /setcpf.")
            return
        
        if not nome:
            bot.send_message(userid, "Seu nome ainda não está configurado. Para configurá-lo, use o comando /setnome.")
            return
        
        if saldo < 10:
            bot.send_message(userid, "Para realizar um saque, o valor mínimo exigido pela nossa plataforma de pagamentos é de R$ 10,00.")
            return
        
        msg = f"Você deseja realizar o saque via Pix? O valor será depositado integralmente na chave Pix vinculada ao seu CPF. Certifique-se de que o CPF configurado é uma chave Pix válida, pois, caso a chave esteja incorreta, o valor será perdido, sem possibilidade de reembolso. Lembrando que haverá uma taxa de {taxa_saque}% sobre o valor do saque."
        mkp = InlineKeyboardMarkup(row_width=1)
        btn = InlineKeyboardButton("💸 Sacar Agora!", callback_data="confirmar_saque")
        btn1 = InlineKeyboardButton('<< Voltar', callback_data="perfil_info")
        mkp.add(btn, btn1)
        bot.edit_message_text(msg, userid, call.message.message_id, reply_markup=mkp)
    except:
        pass

@bot.callback_query_handler(func=lambda call: call.data == "estatisticas_config")
def estatisticas(call):
    try:
        userid = call.from_user.id
        message_id = call.message.message_id

        assinantes = db.getAssinantes()
        nao_assinantes = db.getNotAssinantes()
        todos = db.getAllUsers()

        msg = f"📊 Estatísticas do bot:\n\n👑 Assinantes: {len(assinantes)}\n📉 Não Assinantes: {len(nao_assinantes)}\n👤 Todos os Usuários: {len(todos)}"

        mkp = InlineKeyboardMarkup(row_width=1)
        btn = InlineKeyboardButton("<< Voltar", callback_data="menu_adm")
        mkp.add(btn)

        bot.edit_message_text(msg, userid, message_id, reply_markup=mkp)
    except Exception as e:
        print(f"Erro no mostrar estatisticas: {e}")

@bot.callback_query_handler(func=lambda call: call.data == "confirmar_saque")
def confirmarSaque(call):
    try:
        config = js.getDict(dr.config)
        userid = call.from_user.id

        if userid in sacando:
            return
        sacando.append(userid)

        admin = config['admin']
        taxa_saque = config['taxa_saque']
        taxa_venda = config['taxa_venda']
        cpf = config['person']['cpf']
        nome = config['person']['nome']
        saldo = db.getSaldo()

        if not cpf:
            sacando.remove(userid)
            bot.send_message(userid, "Seu CPF ainda não está configurado. Para configurá-lo, use o comando /setcpf.")
            return
        
        if not nome:
            sacando.remove(userid)
            bot.send_message(userid, "Seu nome ainda não está configurado. Para configurá-lo, use o comando /setnome.")
            return
        
        if saldo < 10:
            sacando.remove(userid)
            bot.send_message(userid, "Para realizar um saque, o valor mínimo exigido pela nossa plataforma de pagamentos é de R$ 10,00.")
            return

        try:
            bot.delete_message(userid, call.message.message_id)
        except:
            pass

        try:
            msg_to_del = bot.send_message(userid, "⏳").message_id
        except:
            msg_to_del = None

        if db.descontarSaldo(saldo):
            dpay = js.getDict(dr.config, "digitopay")

            client = dpay['client']
            secret = dpay['secret']

            DPay = DigitoPay(client, secret)

            valor_porcentagem = saldo * taxa_saque / 100
            valor_saque = saldo - valor_porcentagem

            response = DPay.withdraw(cpf, nome, valor_saque)
            sucesso = response.get("success", None)

            try:
                bot.delete_message(userid, msg_to_del)
            except:
                pass
            if sucesso:
                try:
                    mkp = InlineKeyboardMarkup(row_width=1)
                    btn = InlineKeyboardButton("Atendimento Online", url='t.me/iderDetryu')
                    mkp.add(btn)
                    bot.send_message(userid, f"✅ Solicitação de saque enviada com sucesso! Os saques são processados em até 24 horas. Para agilizar, entre em contato com o suporte.\n\n💸 Valor Solicitado: R${valor_saque:.2f}", reply_markup=mkp)
                except:
                    pass
                try:
                    bot_principal = js.getDict(dr.config, "bot_principal")
                    bot_principal = telebot.TeleBot(bot_principal)
                    bot_principal.send_message(js.getDict("/root/bots/fluxo-bot/config/config.json", "admin"), "Novo saque solicitado!")
                except:
                    pass
            else:
                db.addSaldo(saldo)
                bot.send_message(userid, "Não foi possível realizar seu saque. Se esse erro persistir, entre em contato com o suporte.")
        else:
            try:
                bot.delete_message(userid, msg_to_del)
            except:
                pass
            bot.send_message(userid, "Ocorreu um erro interno.")
        sacando.remove(userid)
    except:
        try:
            sacando.remove(userid)
        except:
            pass
        pass

#========================#

@bot.chat_join_request_handler(func=lambda message: True)
def joinChatRequest(message):
    try:
        userid = message.from_user.id
        chat_id = message.chat.id
        link = message.invite_link.invite_link

        chat = js.getDict(dr.config, "chat")

        if str(chat) == str(chat_id):
            if db.validateJoinRequest(userid, link):
                if bot.approve_chat_join_request(chat_id, userid):
                    bot.send_message(userid, "Sua solicitação para ingressar no grupo VIP foi aprovada! Se o grupo ainda não aparecer para você, tente clicar novamente no link de acesso 👆.")
            else:
                print("Acesso inválido.")
            
    except Exception as e:
        print(e)

#========================#

def banirUsuarioExpirado(usuario):
    try:
        userid = usuario[0]
        config = js.getDict(dr.config)
        admin = config['admin']
        chat = config['chat']

        # Tenta desbanir o usuário e enviar uma mensagem de notificação
        db.setColumnUsuario('link', None, userid)
        db.setColumnUsuario('plano_until', None, userid)
        try:
            bot.unban_chat_member(chat, userid)  # Apenas chama sem verificar retorno
            nome_gp = bot.get_chat(chat).title
            msg = f"📅 Sua assinatura no grupo {nome_gp} expirou. Para renovar, clique no botão abaixo:"
            mkp = InlineKeyboardMarkup(row_width=1)
            btn = InlineKeyboardButton('Renovar Assinatura', callback_data="menu_principal")
            mkp.add(btn)
            bot.send_message(userid, msg, reply_markup=mkp)
        
        except Exception as e:  # Captura a exceção específica e registra
            bot.send_message(admin, f"A assinatura de um usuário expirou, mas não consegui remover o usuário do grupo. "
                                     f"Erro: {str(e)}. Faça a remoção manual: <a href='tg://user?id={userid}'>{userid}</a>")
            
    except Exception as e:  # Captura exceções de nível superior
        bot.send_message(admin, f"Ocorreu um erro ao tentar processar a remoção do usuário {userid}. "
                                 f"Erro: {str(e)}.")

def whileVerificarUsuarios():
    while True:
        try:
            usuarios = db.getExpiredUsers()
            for usuario in usuarios:
                banirUsuarioExpirado(usuario)
        except Exception as e:
            print(f"Erro no loop: {e}")
        time.sleep(10)

thread_banir_user = threading.Thread(target=whileVerificarUsuarios)
thread_banir_user.daemon = True
thread_banir_user.start()

while True:
    try:
        bot.polling()
    except:
        time.sleep(10)