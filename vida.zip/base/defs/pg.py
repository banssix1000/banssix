from defs import js, dr, db
from modules.digitopay import DigitoPay
from modules.fdevs.fdevs import generatePerson
from modules.qrcodegen.qr import gerar_qrcode
from datetime import datetime, timezone, timedelta
import telebot
import pytz
import time
import threading

fuso = pytz.timezone('America/Sao_Paulo')

bot = telebot.TeleBot(js.getDict(dr.config, "bot_token"))

def calcular_data(minutes=None, hours=None, days=None):
    # Data e hora atual em UTC com timezone
    data_atual = datetime.now(timezone.utc)
    
    # Adiciona os valores de days, hours, e minutes se fornecidos
    if days:
        data_atual += timedelta(days=days)
    if hours:
        data_atual += timedelta(hours=hours)
    if minutes:
        data_atual += timedelta(minutes=minutes)
    
    # Retorna a data no formato ISO 8601
    return data_atual.strftime("%Y-%m-%dT%H:%M:%SZ")

def gerarPixDigitoPay(userid, plano_id):
    try:
        plano = db.getPlan(plano_id)

        id = plano[0]
        nome = plano[1]
        dias = plano[2]
        price = plano[3]

        dpay = js.getDict(dr.config, "digitopay")

        client = dpay['client']
        secret = dpay['secret']

        DPay = DigitoPay(client, secret)

        person = generatePerson()

        cpf = person[0].get("cpf", "860.329.299-06")
        name = person[0].get("nome", "AndrÃ© ClÃ¡udio AndrÃ© GalvÃ£o")
        expiration = calcular_data(minutes=15)

        obj = {
                "dueDate": expiration,
                "paymentOptions": [
                    "PIX"
                ],
                "person": {
                    "cpf": cpf,
                    "name": name
                },
                "value": float(price),
                "callbackUrl": None,
                "splitConfiguration": None
            }
        
        response = DPay.create_payment(obj)

        id = response.get("id")
        pixCopiaECola = response.get("pixCopiaECola")
        status = DPay.get_status_transaction(id)
        qrcode_bytes = gerar_qrcode(pixCopiaECola)

        if id and pixCopiaECola and status == '"PENDENTE"':
            if '"' in status:
                status = status.replace('"', '')
            
            if db.insertPayment(id, userid, status, plano_id, dias, price):
                return pixCopiaECola, qrcode_bytes
            else:
                return False, False
        else:
            return False, False
    except Exception as e:
        print(f"Erro ao criar pagamento digitopay: {e}")
        return False, False

def verificarPagamentoDpay(pagamento):
    try:
        dpay = js.getDict(dr.config, "digitopay")

        client = dpay['client']
        secret = dpay['secret']

        Dpay = DigitoPay(client, secret)

        identifier = pagamento[0]
        userid = pagamento[1]
        plano = pagamento[2]
        validade = pagamento[3]
        valor = pagamento[5]
        valor = float(valor)
        admin = js.getDict(dr.config, "admin")

        response = Dpay.get_status_transaction(identifier)

        if response:
            if '"' in response:
                response = response.replace('"', '')
            
            if response == "REALIZADO":
                #fez o pic
                if db.setColumnPagamento('status', response, identifier):

                    #paga o dono

                    try:
                        taxa_venda = js.getDict(dr.config, "taxa_venda")
                        valor -= taxa_venda * valor / 100
                        if db.addSaldo(valor):
                            bot.send_message(admin, f"✅ Nova Venda Realizada!\n\n👤 UserID: {userid}\n📅 Validade do Plano: {'Vitalício' if validade.lower() == 'v' else f'{validade} dias'}\n💰 Sua Comissão: R${valor:.2f}")
                    except Exception as e:
                        print(f"Erro ao enviar msg pro adm: {e}")

                    try:
                        canal_vip = js.getDict(dr.config, "chat")
                        invite_link = bot.create_chat_invite_link(canal_vip, f"Link do userID: {userid}", creates_join_request=True).invite_link
                        if validade.lower() == "v":
                            db.setColumnUsuario('plano_until', 'v', userid)
                            db.setColumnUsuario('link', invite_link, userid)
                        else:
                            dias = int(validade)
                            now = datetime.now(fuso)
                            now += timedelta(days=dias)
                            now = now.strftime('%d/%m/%Y - %H:%M:%S')
                            db.setColumnUsuario('plano_until', now, userid)
                            db.setColumnUsuario('link', invite_link, userid)
                        
                        bot.send_message(userid, f"✅ Pagamento aprovado! Seu link de acesso:\n\n{invite_link}")
                    except Exception as e:
                        print(e)
            else:
                db.setColumnPagamento('status', response, identifier)
        else:
            print("No response dpay")
    except Exception as e:
        print(f"Erro ao verificar pagamento digitopay: {e}")

def whileDpay():
    while True:
        try:
            pagamentos = db.getPayments('PENDENTE')
            for pagamento in pagamentos:
                verificarPagamentoDpay(pagamento)
        except Exception as e:
            print(f"Erro no loop dpay: {e}")
        time.sleep(5)

thread_dpay = threading.Thread(target=whileDpay)
thread_dpay.daemon = True
thread_dpay.start()