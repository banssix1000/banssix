#=======================#

import sqlite3
from defs import dr, js
import random
import string
import datetime
import pytz
import telebot

fuso = pytz.timezone('America/Sao_Paulo')

#=======================#

def create_connection(path=None):
    try:
        if not path:
            conn = sqlite3.connect(dr.database)
        else:
            conn = sqlite3.connect(path)
        return conn, conn.cursor()
    except Exception as e:
        print(f"Erro ao criar conexão: {e}")
        return None, None

def close_conn(conn, cursor):
    try:
        cursor.close()
        conn.close()
        return True
    except Exception as e:
        print(f"Erro ao fechar conexão: {e}")
        return False

def gerar_token(len):
    caracteres = string.ascii_letters + string.digits
    token = ''.join(random.choice(caracteres) for _ in range(len))
    return token

#=======================#

def getMedia():
    try:
        conn, cursor = create_connection()
        cursor.execute("SELECT * FROM midia")
        media = cursor.fetchone()
        if not media:
            return None, None
        else:
            return media
    except Exception as e:
        print(f"Erro ao pegar media: {e}")
        return None, None
    finally:
        try:
            close_conn(conn, cursor)
        except:
            pass

def deleteMidia():
    try:
        conn, cursor = create_connection()
        cursor.execute("DELETE FROM midia")
        conn.commit()
        return True
    except Exception as e:
        print(f"Erro ao deletar midia: {e}")
        return False
    finally:
        try:
            close_conn(conn, cursor)
        except:
            pass

def gravarMidia(bytes, type):
    try:
        conn, cursor = create_connection()
        cursor.execute("INSERT INTO midia (midia, midia_type) VALUES (?,?)", (bytes, type,))
        conn.commit()
        return True
    except Exception as e:
        print(f"Erro ao gravar midia: {e}")
        return False
    finally:
        try:
            close_conn(conn, cursor)
        except:
            pass

#=======================#

def getPlan(plan_id):
    try:
        conn, cursor = create_connection()
        cursor.execute("SELECT * FROM planos WHERE id = ?", (plan_id,))
        return cursor.fetchone()
    except Exception as e:
        print(f"Erro ao pegar plano pelo id: {e}")
        return False
    finally:
        try:
            close_conn(conn, cursor)
        except:
            pass

def criarPlan():
    try:
        token = None
        while not token or getPlan(token):
            token = gerar_token(10)
        conn, cursor = create_connection()
        cursor.execute("INSERT INTO planos (id) VALUES (?)", (token,))
        conn.commit()
        return token
    except Exception as e:
        print(f"Erro ao criar token: {e}")
        return False
    finally:
        try:
            close_conn(conn, cursor)
        except:
            pass

def editarColunaPlan(plan_id, coluna, valor):
    try:
        conn, cursor = create_connection()
        sql = f"UPDATE planos SET {coluna} = ? WHERE id = ?"
        cursor.execute(sql, (valor, plan_id,))
        conn.commit()
        return True
    except Exception as e:
        print(f"Erro ao editar coluna dos planos: {e}")
        return False
    finally:
        try:
            close_conn(conn, cursor)
        except:
            pass

def getAllPlans():
    try:
        conn, cursor = create_connection()
        # Ordenar pelo preço com valores nulos no final
        cursor.execute("SELECT * FROM planos ORDER BY price ASC NULLS LAST")
        return cursor.fetchall()
    except Exception as e:
        print(f"Erro ao pegar todos os planos: {e}")
        return []
    finally:
        try:
            close_conn(conn, cursor)
        except:
            pass

def deletePlan(plan_id):
    try:
        conn, cursor = create_connection()
        cursor.execute("DELETE FROM planos WHERE id = ?", (plan_id,))
        conn.commit()
        return True
    except Exception as e:
        print(f"Erro ao deletar plano: {e}")
        return False
    finally:
        try:
            close_conn(conn, cursor)
        except:
            pass

#=======================#

def insertUser(userid):
    try:
        conn, cursor = create_connection()
        cursor.execute("SELECT * FROM usuarios WHERE id = ?", (userid,))
        if cursor.fetchone():
            return True
        else:
            now = datetime.datetime.now(fuso).strftime('%d/%m/%Y às %H:%M:%S')
            cursor.execute("INSERT INTO usuarios (id, joined) VALUES (?,?)", (userid, now,))
            conn.commit()
            return True
    except Exception as e:
        print(f"Erro ao inserir usuario: {e}")
        return False
    finally:
        try:
            close_conn(conn, cursor)
        except:
            pass

def setColumnUsuario(coluna, valor, userid):
    try:
        conn, cursor = create_connection()
        sql = f"UPDATE usuarios SET {coluna} = ? WHERE id = ?"
        cursor.execute(sql, (valor, userid,))
        conn.commit()
        return True
    except Exception as e:
        print(f"Erro ao setar coluna user: {e}")
        return False
    finally:
        try:
            close_conn(conn, cursor)
        except:
            pass

def validateJoinRequest(userid, link):
    try:
        conn, cursor = create_connection()
        cursor.execute("SELECT * FROM usuarios WHERE id = ?", (userid,))
        userdata = cursor.fetchone()
        user_link = userdata[2]
        validade = userdata[3]
        if user_link and validade:

            if str(user_link) != str(link):
                return False
            if validade.lower() == "v":
                return True
            
            validade = datetime.datetime.strptime(validade, '%d/%m/%Y - %H:%M:%S')
            validade = fuso.localize(validade)
            now = datetime.datetime.now(fuso)

            if now > validade:
                return False
            else:
                return True
            
        else:
            return False
    except Exception as e:
        print(f"Erro ao validar link: {e}")
        return False
    finally:
        try:
            close_conn(conn, cursor)
        except:
            pass

def getExpiredUsers():
    try:
        conn, cursor = create_connection()
        cursor.execute("SELECT * FROM usuarios")
        usuarios = cursor.fetchall()
        lista_users = []

        for usuario in usuarios:
            link = usuario[2]
            validade = usuario[3]
            if link and validade:
                if validade.lower() != "v":
                    validade = datetime.datetime.strptime(validade, '%d/%m/%Y - %H:%M:%S')
                    validade = fuso.localize(validade)
                    now = datetime.datetime.now(fuso)

                    if now > validade:
                        lista_users.append(usuario)
        
        return lista_users
    except Exception as e:
        print(f"Erro ao pegar lista de usuarios expirados: {e}")
        return []
    finally:
        try:
            close_conn(conn, cursor)
        except:
            pass

def getAssinantes():
    try:
        conn, cursor = create_connection()
        cursor.execute("SELECT * FROM usuarios WHERE link IS NOT NULL AND plano_until IS NOT NULL")
        return cursor.fetchall()
    except Exception as e:
        print(f"Erro ao pegar assinantes: {e}")
        return []
    finally:
        try:
            close_conn(conn, cursor)
        except:
            pass

def getNotAssinantes():
    try:
        conn, cursor = create_connection()
        cursor.execute("SELECT * FROM usuarios WHERE link IS NULL AND plano_until IS NULL")
        return cursor.fetchall()
    except Exception as e:
        print(f"Erro ao pegar assinantes: {e}")
        return []
    finally:
        try:
            close_conn(conn, cursor)
        except:
            pass

def getAllUsers():
    try:
        conn, cursor = create_connection()
        cursor.execute("SELECT * FROM usuarios")
        return cursor.fetchall()
    except Exception as e:
        print(f"Erro ao pegar usuarios: {e}")
        return []
    finally:
        try:
            close_conn(conn, cursor)
        except:
            pass

def getUserById(userid):
    try:
        conn, cursor = create_connection()
        cursor.execute("SELECT * FROM usuarios WHERE id = ?", (userid,))
        return cursor.fetchone()
    except Exception as e:
        print(f"Erro ao pegar usuário pelo id: {e}")
        return []
    finally:
        try:
            close_conn(conn, cursor)
        except:
            pass

#=======================#

def insertPayment(pagamento_id, userid, status, plano, dias, valor):
    try:
        conn, cursor = create_connection()
        cursor.execute("INSERT INTO pagamentos (id, userid, plano, validade, status, valor) VALUES (?,?,?,?,?,?)", (pagamento_id, userid, plano, dias, status, valor,))
        conn.commit()
        return True
    except Exception as e:
        print(f"Erro ao inserir pagamento: {e}")
        return False
    finally:
        try:
            close_conn(conn, cursor)
        except:
            pass

def setColumnPagamento(coluna, valor, pagamento_id):
    try:
        conn, cursor = create_connection()
        sql = f"UPDATE pagamentos SET {coluna} = ? WHERE id = ?"
        cursor.execute(sql, (valor, pagamento_id,))
        conn.commit()
        return True
    except Exception as e:
        print(f"Erro ao setar coluna pg: {e}")
        return False
    finally:
        try:
            close_conn(conn, cursor)
        except:
            pass

def getPayments(status):
    try:
        conn, cursor = create_connection()
        cursor.execute("SELECT * FROM pagamentos WHERE status = ?", (status,))
        return cursor.fetchall()
    except Exception as e:
        print(f"Erro ao pegar pagamentos: {e}")
        return []
    finally:
        try:
            close_conn(conn, cursor)
        except:
            pass

#=======================#

def selectMessage(message_id):
    try:
        conn, cursor = create_connection()
        cursor.execute("SELECT * FROM mensagens WHERE id = ?", (message_id,))
        return cursor.fetchone()
    except Exception as e:
        print(f"Erro ao pegar mensagem pelo id: {e}")
        return []
    finally:
        try:
            close_conn(conn, cursor)
        except:
            pass

def createMessage(to):
    try:
        message_id = None
        while not message_id or selectMessage(message_id):
            message_id = gerar_token(10)
        
        conn, cursor = create_connection()
        cursor.execute("INSERT INTO mensagens (id, 'to') VALUES (?,?)", (message_id, to,))
        conn.commit()
        return message_id
    except Exception as e:
        print(f"Erro ao criar message: {e}")
        return False
    finally:
        try:
            close_conn(conn, cursor)
        except:
            pass

def setColumnMessage(message_id, coluna, valor):
    try:
        conn, cursor = create_connection()
        sql = f"UPDATE mensagens SET '{coluna}' = ? WHERE id = ?"
        cursor.execute(sql, (valor, message_id,))
        conn.commit()
        return True
    except Exception as e:
        print(f"Erro ao setar coluna ms: {e}")
        return False
    finally:
        try:
            close_conn(conn, cursor)
        except:
            pass

def deleteMessage(msg_id):
    try:
        conn, cursor = create_connection()
        cursor.execute("DELETE FROM mensagens WHERE id = ?", (msg_id,))
        conn.commit()
        return True
    except Exception as e:
        print(f"Erro ao deletar mensagem: {e}")
        return False
    finally:
        try:
            close_conn(conn, cursor)
        except:
            pass

#=======================#

def getBotId():
    try:
        bot_token = js.getDict(dr.config, "bot_token")
        return telebot.TeleBot(bot_token).get_me().id
    except:
        return None

def verificarSaldoBot():
    try:
        conn, cursor = create_connection("/root/bots/fluxo-bot/storage-bots/database.db")
        bot_id = getBotId()
        if bot_id:
            cursor.execute("SELECT * FROM saldos WHERE id = ?", (bot_id,))
            if cursor.fetchone():
                return True
            else:
                cursor.execute("INSERT INTO saldos (id) VALUES (?)", (bot_id,))
                conn.commit()
                return True
        else:
            return False
    
    except Exception as e:
        print(f"Erro ao verificar saldo bot: {e}")
        return False
    
    finally:
        try:
            close_conn(conn, cursor)
        except:
            pass

def getSaldo():
    try:
        verificarSaldoBot()
        id_bot = getBotId()
        conn, cursor = create_connection("/root/bots/fluxo-bot/storage-bots/database.db")
        cursor.execute("SELECT * FROM saldos WHERE id = ?", (id_bot,))
        return cursor.fetchone()[1]
    except Exception as e:
        print(f"Erro ao pegar saldo: {e}")
        return 0
    finally:
        try:
            close_conn(conn, cursor)
        except:
            pass

def addSaldo(valor):
    try:
        verificarSaldoBot()
        id_bot = getBotId()
        conn, cursor = create_connection("/root/bots/fluxo-bot/storage-bots/database.db")
        cursor.execute("UPDATE saldos SET saldo = saldo + ? WHERE id = ?", (valor, id_bot,))
        conn.commit()
        return True
    except Exception as e:
        print(f"Erro ao setar saldo: {e}")
        return False
    finally:
        try:
            close_conn(conn, cursor)
        except:
            pass

def descontarSaldo(valor):
    try:
        verificarSaldoBot()
        id_bot = getBotId()
        saldo = getSaldo()

        saldo -= float(valor)
        if saldo <= 0:
            saldo = 0

        conn, cursor = create_connection("/root/bots/fluxo-bot/storage-bots/database.db")
        cursor.execute("UPDATE saldos SET saldo = ? WHERE id = ?", (saldo, id_bot,))
        conn.commit()

        return True
    except Exception as e:
        print(f"Erro ao descontar saldo: {e}")
        return False
    finally:
        try:
            close_conn(conn, cursor)
        except:
            pass