import json

def getDict(path, key=False):
    attempts = 5
    while attempts >= 1:
        try:
            with open(path, "r", encoding="utf-8") as file:
                dados = json.load(file)
                if key:
                    return dados[str(key)]
                else:
                    return dados
        except Exception as e:
            print(f"Erro ao buscar dicionário: {path}\n\nErro: {e}\n\n")
            attempts -= 1
    return False

def saveDict(dict, path):
    attempts = 5
    while attempts >= 1:
        try:
            with open(path, "w", encoding="utf-8") as file:
                json.dump(dict, file, indent=4)
                return True
        except Exception as e:
            print(f"Erro ao salvar dicionário: {path}\n\nErro: {e}\n\n")
            attempts -= 1
    return False
