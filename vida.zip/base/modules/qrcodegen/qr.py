import qrcode
from io import BytesIO

def gerar_qrcode(texto):
    try:
        # Cria o QR code
        qr = qrcode.QRCode(
            version=1,  # Controla o tamanho do QR code
            error_correction=qrcode.constants.ERROR_CORRECT_L,
            box_size=10,
            border=4,
        )
        
        # Adiciona o texto ao QR code
        qr.add_data(texto)
        qr.make(fit=True)
        
        # Cria a imagem do QR code
        img = qr.make_image(fill='black', back_color='white')
        
        # Salva a imagem em um buffer de bytes
        buffer = BytesIO()
        img.save(buffer, format="PNG")
        
        # Retorna os bytes da imagem
        return buffer.getvalue()
    
    except Exception as e:
        return False

