import requests

def generatePerson():
    try:
        data = {
            "acao": "gerar_pessoa",
            "sexo": "I",
            "pontuacao": "S",
            "idade": 0,
            "txt_qtde": 1
        }

        response = requests.post("https://www.4devs.com.br/ferramentas_online.php", data=data)
        return response.json()
    except Exception as e:
        print(f"Erro ao gerar pessoa: {e}")
        return {}