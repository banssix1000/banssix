class PaymentError(Exception):
    """Raised when a payment operation fails."""
    pass

class AuthenticationError(PaymentError):
    """Raised when there is an authentication issue."""
    pass

class APIError(PaymentError):
    """Raised when the API returns an error response."""
    pass
