import requests
from .exceptions import PaymentError, AuthenticationError

class DigitoPay:

    def __init__(self, client_id, client_secret):
        self.client_id = client_id
        self.client_secret = client_secret
        self.base_url = "https://api.digitopayoficial.com.br"
        self.token = self.authenticate()
    
    def authenticate(self):
        """Autentica na DIGITOPAY usando client_id e client_secret e retorna o token de acesso."""
        auth_url = f"{self.base_url}/api/token/api"

        data = {
            "clientId": self.client_id,
            "secret": self.client_secret
        }

        response = requests.post(auth_url, json=data)

        if response.status_code == 500:
            raise AuthenticationError(f"Failed to authenticate: {response.json()['mensagem']}")
        elif response.status_code == 200:
            token_data = response.json()
            return token_data.get('accessToken')
        else:
            raise AuthenticationError(f"Failed to authenticate: {response.json()}")

    def _get_headers(self):
        """Retorna os cabeçalhos necessários para a requisição com o token de autenticação."""
        return {
            "Authorization": f"Bearer {self.token}",
            "Content-Type": "application/json"
        }
    
    def create_payment(self, obj):
        """Cria um pagamento na DIGITOPAY."""
        response = requests.post(f"{self.base_url}/api/deposit", json=obj, headers=self._get_headers())
        return response.json()
    
    def get_status_transaction(self, payment_id):
        """Verifica o status de um pagamento."""
        response = requests.get(f"{self.base_url}/api/status/{payment_id}", headers=self._get_headers())
        if response.status_code == 500:
            raise PaymentError(f"Failed to get payment status: {response.json()['mensagem']}")
        elif response.status_code == 200:
            return response.text

    def withdraw(self, chave_pix, nome, valor):
        """Realiza um saque na DIGITOPAY"""
        obj = {
            "paymentOptions": [
                "PIX"
            ],
            "person": {
                "pixKeyTypes": None,
                "pixKey": chave_pix,
                "name": nome
            },
            "value": float(valor),
            "endToEndId": None,
            "callbackUrl": None,
            "splitConfiguration": None
        }

        response = requests.post(f"{self.base_url}/api/withdraw", json=obj, headers=self._get_headers())

        return response.json()
