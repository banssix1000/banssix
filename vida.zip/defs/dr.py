config = "config/config.json"
database = "storage/database.db"

menu_txt = "editaveis/menu.txt"