#===========================#

import sqlite3
from defs import dr, js
import datetime
import pytz

fuso = pytz.timezone("America/Sao_Paulo")

#===========================#

def create_connection():
    try:
        conn = sqlite3.connect(dr.database)
        cursor = conn.cursor()
        return conn, cursor
    except Exception as e:
        print(f"Erro ao estabelecer conexão: {e}")
        return None, None

def close_connection(conn, cursor):
    try:
        cursor.close()
        conn.close()
        return True
    except Exception as e:
        print(f"Erro ao fechar conexão: {e}")
        return False

#===========================#

def insertUser(userid):
    try:
        conn, cursor = create_connection()
        cursor.execute("SELECT * FROM usuarios WHERE id = ?", (userid,))
        if cursor.fetchone():
            return True
        else:
            now = datetime.datetime.now(fuso).strftime("%d/%m/%Y às %H:%M:%S")
            cursor.execute("INSERT INTO usuarios (id, createdat) VALUES (?,?)", (userid, now,))
            conn.commit()
            return True
    except Exception as e:
        print(f"Erro ao inserir usuário: {e}")
        return False
    finally:
        try:
            close_connection(conn, cursor)
        except:
            pass

#===========================#

def insert_bot(bot_id, userid, username):
    try:
        conn, cursor = create_connection()
        cursor.execute("SELECT * FROM bots WHERE id = ?", (bot_id,))
        if cursor.fetchone():
            return True
        else:
            cursor.execute("INSERT INTO bots (id, dono, username) VALUES (?,?,?)", (bot_id, userid, username))
            conn.commit()
            return True
    except Exception as e:
        print(f"Erro ao verificar/inserir bot: {e}")
        return False
    finally:
        close_connection(conn, cursor)

def get_user_bots(userid):
    try:
        conn, cursor = create_connection()
        cursor.execute("SELECT * FROM bots WHERE dono = ?", (userid,))
        return cursor.fetchall()
    except Exception as e:
        print(f"Erro ao pegar bots do usuário: {e}")
        return False
    finally:
        close_connection(conn, cursor)

def get_bot(id, userid):
    try:
        conn, cursor = create_connection()
        cursor.execute("SELECT * FROM bots WHERE id = ? AND dono = ?", (id, userid,))
        return cursor.fetchone()
    except Exception as e:
        print(f"Erro ao pegar bot pelo id: {e}")
        return False
    finally:
        close_connection(conn, cursor)

def delete_bot(id):
    try:
        conn, cursor = create_connection()
        cursor.execute("DELETE FROM bots WHERE id = ?", (id,))
        conn.commit()
        return True
    except Exception as e:
        print(f"Erro ao deletar bot: {e}")
        return False
    finally:
        close_connection(conn, cursor)