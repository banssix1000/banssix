import os
import subprocess
import shutil
from defs import db, dr, js
import telebot
import zipfile

bot = telebot.TeleBot(js.getDict(dr.config, "bot"))

def get_subdirectories(parent_folder):
    # Lista para armazenar os nomes das subpastas
    subdirectories = []
    
    # Itera sobre os itens na pasta pai
    for item in os.listdir(parent_folder):
        item_path = os.path.join(parent_folder, item)
        # Verifica se o item é um diretório
        if os.path.isdir(item_path):
            subdirectories.append(item)  # Adiciona o nome da pasta à lista

    return subdirectories

def update_files_from_zip(zip_path, target_folder):
    update_folder = 'update_folder'  # Pasta temporária para os arquivos extraídos

    # Cria a pasta de backup do diretório de destino
    backup_folder = target_folder + '_backup'
    if os.path.exists(backup_folder):
        shutil.rmtree(backup_folder)  # Remove a pasta de backup se já existir
    shutil.copytree(target_folder, backup_folder)  # Faz uma cópia de segurança

    try:
        # Cria a pasta para os arquivos extraídos
        if os.path.exists(update_folder):
            shutil.rmtree(update_folder)  # Remove a pasta se já existir
        os.makedirs(update_folder)  # Cria a pasta para os arquivos extraídos

        # Descompacta o arquivo zip
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            zip_ref.extractall(update_folder)  # Extrai os arquivos

        for root, dirs, files in os.walk(update_folder):
            for name in files:
                file_path = os.path.join(root, name)
                # Caminho correspondente no diretório de destino
                relative_path = os.path.relpath(file_path, update_folder)
                target_file_path = os.path.join(target_folder, relative_path)

                # Verifica se o arquivo deve ser atualizado e se não está na pasta storage
                if not target_file_path.startswith(os.path.join(target_folder, 'storage')):
                    if os.path.exists(target_file_path):
                        # Remove o arquivo existente
                        os.remove(target_file_path)
                    
                    # Cria o diretório se não existir
                    os.makedirs(os.path.dirname(target_file_path), exist_ok=True)
                    
                    # Copia o novo arquivo
                    shutil.copyfile(file_path, target_file_path)

            for name in dirs:
                dir_path = os.path.join(root, name)
                # Caminho correspondente no diretório de destino
                relative_dir_path = os.path.relpath(dir_path, update_folder)
                target_dir_path = os.path.join(target_folder, relative_dir_path)

                # Verifica se a pasta deve ser criada e se não está na pasta storage
                if not target_dir_path.startswith(os.path.join(target_folder, 'storage')):
                    if not os.path.exists(target_dir_path):
                        os.makedirs(target_dir_path)

        # Limpa a pasta temporária
        shutil.rmtree(update_folder)

        # Remove a pasta de backup se a atualização for bem-sucedida
        shutil.rmtree(backup_folder)

        return True  # Atualização bem-sucedida
    except Exception as e:
        # Restaura o diretório de destino a partir do backup
        shutil.rmtree(target_folder)
        shutil.copytree(backup_folder, target_folder)  # Restaura a partir do backup
        shutil.rmtree(backup_folder)  # Remove a pasta de backup
        print(f"Erro ao atualizar arquivos: {e}")
        return False  # Falha na atualização

def new_bot(token, bot_id, userid, username):
    try:
        bot_dir = f"/root/bots/fluxo-bot/bots/{bot_id}"
        bot_base = f"/root/bots/fluxo-bot/base"

        if os.path.exists(bot_dir):
            return 'EXISTENTE'
        else:
            os.makedirs(bot_dir, exist_ok=True)
            for item in os.listdir(bot_base):
                source_item = os.path.join(bot_base, item)
                dest_item = os.path.join(bot_dir, item)
                if os.path.isdir(source_item):
                    shutil.copytree(source_item, dest_item, dirs_exist_ok=True)
                else:
                    shutil.copy2(source_item, dest_item)
            
            config_json = js.getDict(f"{bot_dir}/storage/config.json")

            config_json['bot_token'] = token
            config_json['admin'] = f"{userid}"
            config_json['dev'] = bot.get_chat(js.getDict(dr.config, "admin")).username
            config_json['bot_principal'] = js.getDict(dr.config, "bot")

            js.saveDict(config_json, f"{bot_dir}/storage/config.json")

            subprocess.run(['/root/bots/fluxo-bot/venv/bin/pip', 'install', '-r', 'requirements.txt'], cwd=bot_dir)

            service_content = f"""
[Unit]
Description=Bot {bot_id} Dono: {userid}
After=network.target

[Service]
User=root
WorkingDirectory={bot_dir}
ExecStart=/root/bots/fluxo-bot/venv/bin/python3 {bot_dir}/main.py
Restart=always

[Install]
WantedBy=multi-user.target
"""
            with open(f'/etc/systemd/system/{bot_id}.service', 'w') as f:
                f.write(service_content)
            
            subprocess.run(['systemctl', 'daemon-reload'])
            subprocess.run(['systemctl', 'start', f'{bot_id}.service'])
            subprocess.run(['systemctl', 'enable', f'{bot_id}.service'])

            db.insert_bot(bot_id, userid, username)
            return f"SUCCESS:{username}"
    except Exception as e:
        print(f"Erro ao criar bot! {e}")
        return f"ERROR:{e}"

def get_bots(userid):
    try:
        user_bots = db.get_user_bots(userid)
        bots = []

        for bot in user_bots:
            bot_dict = {
                "bot_id": bot[0],
                "bot_uname": bot[2]
            }

            bot_file = f"/root/bots/fluxo-bot/bots/{bot[0]}"
            if os.path.exists(bot_file):
                bots.append(bot_dict)
        
        return bots
    except Exception as e:
        print(f"Erro ao pegar bots: {e}")
        return []

def delete_bot(userid, bot, system=False):
    try:
        bot_path = f"/root/bots/fluxo-bot/bots/{bot}"
        bot_data = db.get_bot(bot, userid)
        
        if bot_data or system == True:
            # Parar e desabilitar o serviço do bot
            subprocess.run(['systemctl', 'stop', f'{bot}.service'], check=True)
            subprocess.run(['systemctl', 'disable', f'{bot}.service'], check=True)
            
            # Remover o arquivo de serviço systemd
            service_file = f'/etc/systemd/system/{bot}.service'
            if os.path.exists(service_file):
                os.remove(service_file)
            
            # Recarregar o daemon do systemd
            subprocess.run(['systemctl', 'daemon-reload'], check=True)
            
            # Apagar o diretório do bot se ele existir
            if os.path.exists(bot_path):
                shutil.rmtree(bot_path)
            
            # Remover os dados do bot do banco de dados
            db.delete_bot(bot)
            
            return True
        else:
            return False
    except subprocess.CalledProcessError as e:
        print(f"Erro ao executar um comando do systemd: {e}")
        return 
    except Exception as e:
        print(f"Erro ao apagar bot: {e}")
        return False

def atualizarBots(update_zip):
    try:
        qtdes = 0
        if update_files_from_zip(update_zip, 'base'):
            bots_paths = get_subdirectories('bots')
            for bot in bots_paths:
                bot_path_name = f"bots/{bot}"
                if update_files_from_zip(update_zip, bot_path_name):
                    subprocess.run(['systemctl', 'restart', f'{bot}.service'])
                    print(f"Bot {bot} Atualizado!")
                    qtdes += 1
        return qtdes
    except Exception as e:
        print(f"Erro ao atualizar pastas: {e}")
        return 0
            

